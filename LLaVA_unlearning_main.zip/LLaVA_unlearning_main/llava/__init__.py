import sys
# 添加目录到 sys.path
sys.path.append('/mnt/home/LLaVA_main')
sys.path.append('/mnt/home/LLaVA_main/llava')
try:
    from .model import LlavaLlamaForCausalLM
except ImportError as e:
    print(f"导入错误！Import error: {e}")
