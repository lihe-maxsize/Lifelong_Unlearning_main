import sys

# 添加目录到 sys.path
sys.path.append('/mnt/home/LLaVA_main')
sys.path.append('/mnt/home/llava-v1.6-vicuna-7b')

import argparse
import json

import torch

from llava.constants import (
    IMAGE_TOKEN_INDEX,
    DEFAULT_IMAGE_TOKEN,
    DEFAULT_IM_START_TOKEN,
    DEFAULT_IM_END_TOKEN,
    IMAGE_PLACEHOLDER,
)
from llava.conversation import conv_templates, SeparatorStyle
from llava.model.builder import load_pretrained_model
from llava.utils import disable_torch_init
from llava.mm_utils import (
    process_images,
    tokenizer_image_token,
    get_model_name_from_path,
)

from PIL import Image

import requests
from PIL import Image
from io import BytesIO
import re
from rouge_score import rouge_scorer
from peft import PeftModel
import os
from copy import deepcopy


# 全局变量，用于指定adapter的路径
lora_paths = {
    "tasks/TaskA/taskA_forget.json": "/mnt/home/LLaVA_main/unlearned_models_official/single_task_adapter/po"
                                     "/po_A_llava_lora",
    "tasks/TaskB/taskB_forget.json": "/mnt/home/LLaVA_main/unlearned_models_official/single_task_adapter/po"
                                     "/po_B_llava_lora",
    "tasks/TaskC/taskC_forget.json": "/mnt/home/LLaVA_main/unlearned_models_official/single_task_adapter/po"
                                     "/po_C_llava_lora",
    "tasks/TaskD/taskD_forget.json": "/mnt/home/LLaVA_main/unlearned_models_official/single_task_adapter/po"
                                     "/po_D_llava_lora"
}


def find_matching_lora_path(task_value, lora_paths):
    for key in lora_paths:
        # 检查 task_value 是否是键的一部分
        if task_value in key:
            return lora_paths[key]
    return None


def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def image_parser(args):
    out = args.image_file.split(args.sep)
    return out


def get_answers(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    gpt_answers = []

    # 遍历 JSON 数据列表
    for item in data:
        # 遍历 conversations，找到 'from: gpt' 的回答
        for conversation in item["conversations"]:
            if conversation["from"] == "gpt":
                gpt_answers.append(conversation["value"])

    return gpt_answers


def load_image(image_file):
    if image_file.startswith("http") or image_file.startswith("https"):
        response = requests.get(image_file)
        image = Image.open(BytesIO(response.content)).convert("RGB")
    else:
        image = Image.open(image_file).convert("RGB")
    return image


def load_images(image_files):
    out = []
    for image_file in image_files:
        image = load_image(image_file)
        out.append(image)
    return out


def prepare_query(qs, model):
    """根据模型配置调整查询语句"""
    image_token_se = DEFAULT_IM_START_TOKEN + DEFAULT_IMAGE_TOKEN + DEFAULT_IM_END_TOKEN
    if IMAGE_PLACEHOLDER in qs:
        if model.config.mm_use_im_start_end:
            qs = re.sub(IMAGE_PLACEHOLDER, image_token_se, qs)
        else:
            qs = re.sub(IMAGE_PLACEHOLDER, DEFAULT_IMAGE_TOKEN, qs)
    else:
        if model.config.mm_use_im_start_end:
            qs = image_token_se + "\n" + qs
        else:
            qs = DEFAULT_IMAGE_TOKEN + "\n" + qs
    return qs


class ModelEvaluator:
    def __init__(self, args):
        """初始化并加载模型"""
        disable_torch_init()
        self.model_name = get_model_name_from_path(args.model_path)
        self.tokenizer, self.model, self.image_processor, self.context_len = load_pretrained_model(
            args.model_path, args.model_base, self.model_name
        )

        self.adapter_model = None  # 定义adapter_model，初始化是原始模型
        self.lora_cache = {}

        # 确定对话模式
        if "llama-2" in self.model_name.lower():
            self.conv_mode = "llava_llama_2"
        elif "mistral" in self.model_name.lower():
            self.conv_mode = "mistral_instruct"
        elif "v1.6-34b" in self.model_name.lower():
            self.conv_mode = "chatml_direct"
        elif "v1" in self.model_name.lower():
            self.conv_mode = "llava_v1"
        elif "mpt" in self.model_name.lower():
            self.conv_mode = "mpt"
        else:
            self.conv_mode = "llava_v0"

    def generate_output(self, prompt, images_tensor, image_sizes, args, adapter_enable=False):
        """使用模型生成输出"""
        input_ids = tokenizer_image_token(prompt, self.tokenizer, IMAGE_TOKEN_INDEX, return_tensors="pt").unsqueeze(
            0).cuda()

        with torch.inference_mode():
            if adapter_enable:
                output_ids = self.adapter_model.generate(
                    input_ids,
                    images=images_tensor,
                    image_sizes=image_sizes,
                    do_sample=True if args.temperature > 0 else False,
                    temperature=args.temperature,
                    top_p=args.top_p,
                    num_beams=args.num_beams,
                    max_new_tokens=args.max_new_tokens,
                    use_cache=True,
                )
            else:
                output_ids = self.model.generate(
                    input_ids,
                    images=images_tensor,
                    image_sizes=image_sizes,
                    do_sample=True if args.temperature > 0 else False,
                    temperature=args.temperature,
                    top_p=args.top_p,
                    num_beams=args.num_beams,
                    max_new_tokens=args.max_new_tokens,
                    use_cache=True,
                )

        outputs = self.tokenizer.batch_decode(output_ids, skip_special_tokens=True)[0].strip()
        return outputs

    def eval_model_single(self, query, image_file, args, require_adapter=False):
        # 使用base_model生成初步的输出
        image = load_image(image_file)
        image_tensor = process_images([image], self.image_processor, self.model.config).to(
            self.model.device, dtype=torch.float16
        )
        image_size = [image.size]

        # 准备查询语句
        qs_prepared = prepare_query(query, self.model)

        # 确保对话模式一致
        conv_mode = self.conv_mode
        if args.conv_mode is not None and conv_mode != args.conv_mode:
            print(
                f"[WARNING] the auto inferred conversation mode is {conv_mode}, while `--conv-mode` is {args.conv_mode}, using {args.conv_mode}"
            )
            conv_mode = args.conv_mode

        # 准备对话模板
        conv = conv_templates[conv_mode].copy()
        conv.append_message(conv.roles[0], qs_prepared)
        conv.append_message(conv.roles[1], None)
        prompt = conv.get_prompt()

        # 生成输出
        output = self.generate_output(prompt, image_tensor, image_size, args, adapter_enable=require_adapter)

        return output

    def load_lora_adapter(self, path):  # 定义加载lora_adapter的模型
        lora_path = path  # 获得adapter的路径，直接就是输入参数
        if lora_path in self.lora_cache:
            print(f"Using cached LoRA Adapter from {lora_path}")
            self.adapter_model = self.lora_cache[lora_path]
        else:
            print(f"Loading LoRA Adapter from {lora_path}...")
            print('Loading LoRA weights...')
            adapter_base_model = deepcopy(self.model)  # 深拷贝一下，避免污染基础模型
            self.adapter_model = PeftModel.from_pretrained(adapter_base_model, lora_path)  # 使用深拷贝的版本去加载lora权重，避免污染基础模型
            self.lora_cache[lora_path] = self.adapter_model
            print("LoRA Adapter loaded and cached.")


def main(args):
    input_json_path = args.data_path
    output_json_path = args.output_path
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    output_data = []

    # 初始化模型评估器
    evaluator = ModelEvaluator(args)

    for item in data:
        # 提取人类的查询
        human_query = next((conv["value"] for conv in item["conversations"] if conv["from"] == "human"), None)
        if human_query:
            prompt = human_query.replace("<image>\n", "").strip()
        else:
            prompt = "Hello!"  # 或者其他默认值

        # 提取图片文件路径
        image = item["image"]

        # 从 JSON 数据中获取 task 值
        task_value = str(item['task'])

        # 根据 task 键获取 lora_paths 对应的值
        selected_path = find_matching_lora_path(task_value, lora_paths)

        if selected_path is not None:
            print(f"当前选择的adapter路径是{selected_path},下面执行接入！\n")
            evaluator.load_lora_adapter(path=selected_path)
            output = evaluator.eval_model_single(prompt, image, args, require_adapter=True)  # 生成单个输出
        else:
            print("没有合适的adapter，默认是不需要遗忘的数据，使用原始模型输出！\n")
            output = evaluator.eval_model_single(prompt, image, args)

        print(f"提示：{prompt}\n 图片：{image}\n 输出：{output}\n\n")
        output_data.append(output)

    # 将输出添加回JSON数据
    for i, item in enumerate(data):
        # 找到 "from" 为 "gpt" 的对话，并更新 "value"
        for conv in item["conversations"]:
            if conv["from"] == "gpt":
                conv["value"] = output_data[i]
                break  # 更新后即可跳出内层循环，避免不必要的遍历
    # 保存新的JSON文件
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print(f"Output saved to {output_json_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", type=str, default="/mnt/home/llava-v1.6-vicuna-7b")
    parser.add_argument("--model-base", type=str, default=None)
    parser.add_argument("--image-file", type=str, default="/mnt/home/LLaVA_main/MLLMbenchmarks/downloaded_images"
                                                          "/Animals/Dog/image_20241017_101424_1.jpg")
    parser.add_argument("--query", type=str, default="Hello!")
    parser.add_argument("--conv-mode", type=str, default=None)
    parser.add_argument("--sep", type=str, default=",")
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--top_p", type=float, default=None)
    parser.add_argument("--num_beams", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=250)
    parser.add_argument("--data_path", type=str, required=True)  # 此参数是待测试数据集的路径
    parser.add_argument("--output_path", type=str, required=True)  # 其参数是输出结果的路径
    args = parser.parse_args()

    main(args)
