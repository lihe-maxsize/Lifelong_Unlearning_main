import json
import os
import base64
import time
from zhipuai import ZhipuAI
from fuzzywuzzy import process

client = ZhipuAI(api_key="")  # 填写您自己的APIKey
processed_items_file = "entity_processed_items.json"


def find_most_similar(target, candidates):
    return process.extractOne(target, candidates)


def find_most_similar_key_and_value(response, tasks_dict):
    most_similar_value = None
    most_similar_key = None
    highest_score = -1  # 相似度初始值

    # 遍历 tasks_dict 的键值对
    for key, value_list in tasks_dict.items():
        # 找到列表中与 response 最相似的值和分数
        candidate, score = find_most_similar(response, value_list)
        if score > highest_score:  # 如果当前分数更高
            highest_score = score
            most_similar_value = candidate
            most_similar_key = key

    return most_similar_key, most_similar_value


def read_txt_files(folder_path):
    file_dict = {}
    type_list = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            base_filename = filename[:-4]  # 移除 '.txt' 后缀
            type_list.append(base_filename)
            with open(os.path.join(folder_path, filename), 'r', encoding='utf-8') as file:
                content = file.read().replace('\n', ', ').replace('、', ', ').replace('_', ' ')  # 正确替换换行符
                # 分割字符串并去除空字符串
                content_list = [item.strip() for item in content.split(', ') if item.strip()]
                file_dict[base_filename] = content_list
    return file_dict, type_list


def load_json(json_path):
    with open(json_path, "r", encoding="utf-8") as file:
        data = json.load(file)
    return data


def get_query(item):
    # 遍历 item 的conversations，找到 'from: human' 的问题
    for conversation in item["conversations"]:
        if conversation["from"] == "human":
            question = conversation["value"]
    return question


def get_match_task(image_path, query):
    img_path = image_path
    with open(img_path, 'rb') as img_file:
        img_base = base64.b64encode(img_file.read()).decode('utf-8')

    message = [
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": img_base
                    }
                },
                {
                    "type": "text",
                    "text": f"{query} \n There is a dataset, the provided image and the "
                            "above question is one sample in this"
                            "dataset. There are several classes in this dataset including ["
                            "Animals、Astronomy、Buildings、Cartoon、Corporation、Movies、Personage、Plants、TV series]. "
                            "\n You"
                            "are required to decide which class this sample belongs to, and output this class "
                            "ONLY. If"
                            "this sample doesn't belong to any of these classes, please output \"None\" ONLY. \n "
                            "Remember,"
                            "YOU DON'T NEED TO ANSWER THE QUESTION OF THIS SAMPLE."
                }
            ]
        }
    ]
    response = client.chat.completions.create(
        model="glm-4v-plus",  # 填写需要调用的模型名称
        temperature=0,
        messages=message
    )
    txt_response = response.choices[0].message.content
    print(f"第一轮的输出是:{txt_response}")

    if txt_response == "None":
        print("模型认为当前问题不属于任何一个类别，默认不在unlearn范围内，返回None！")
        return None, None, None

    most_similar = find_most_similar(str(txt_response), type_list)
    most_similar = most_similar[0]

    entities = all_entities[most_similar]

    new_message = (f"{txt_response} class includes these entities: \n [{entities}].\n"
                   "You are required to judge what entity this sample describes and output the chosen entity ONLY. If "
                   "this"
                   "sample doesn't"
                   "tell any of these entities, please output \"None\" ONLY.")

    new_chat = [
        {
            "content": [
                {
                    "image_url": {
                        "url": img_base
                    },
                    "type": "image_url"
                },
                {
                    "text": f"{query} \n There is a dataset, the provided image and the "
                            "above question is one sample in this"
                            "dataset. There are several classes in this dataset including ["
                            "Animals、Astronomy、Buildings、Cartoon、Corporation、Movies、Personage、Plants、TV series]. "
                            "\n You"
                            "are required to decide which class this sample belongs to, and output this class "
                            "ONLY. If"
                            "this sample doesn't belong to any of these classes, please output \"None\" ONLY. \n "
                            "Remember,"
                            "YOU DON'T NEED TO ANSWER THE QUESTION OF THIS SAMPLE.",
                    "type": "text"
                }
            ],
            "role": "user"
        },
        {
            "content": [
                {
                    "text": f"{txt_response}",
                    "type": "text"
                }
            ],
            "role": "assistant"
        },
        {
            "content": [
                {
                    "text": f"{new_message}",
                    "type": "text"
                }
            ],
            "role": "user"
        }
    ]

    # 第二轮对话
    response = client.chat.completions.create(
        model="glm-4v-plus",
        temperature=0,
        messages=new_chat
    )

    # 获取第二轮对话结果
    txt_response_2 = response.choices[0].message.content
    print(f"第二轮输出是: {txt_response_2}")

    if txt_response_2 == "None":
        print("模型认为没有匹配的实体！返回None！")
        return None, None, None

    # 调用函数
    most_similar_key, most_similar_value = find_most_similar_key_and_value(txt_response_2, tasks_dict)

    # 输出结果
    if most_similar_key is not None:
        print(f"最相似的值是: {most_similar_value}")
        print(f"最相似的值对应的键是: {most_similar_key}")
    else:
        print("没有找到相似的值。")

    return most_similar_key, txt_response, txt_response_2


# 读取已处理项的列表
def load_processed_items(file_path):
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as file:
            return set(json.load(file))  # 读取 JSON 格式的已处理项
    else:
        return set()


# 将已处理的项保存到文件
def save_processed_items(file_path, processed_items):
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(list(processed_items), file, indent=4, ensure_ascii=False)


# 生成唯一的标识符（基于 image 和 query 的组合）
def generate_item_key(image, query):
    return f"{image}|{query}"


if __name__ == "__main__":
    folder_path = "Topics and Entities/Entities/row_text"
    task_path = "tasks/all_tasks"
    all_entities, type_list = read_txt_files(folder_path)
    tasks_dict, task_list = read_txt_files(task_path)

    task_file_path = "tasks/TaskD/taskD_retain.json"

    task_file = load_json(task_file_path)
    processed_items = load_processed_items(processed_items_file)

    for item in task_file:

        query = get_query(item)
        image = item["image"]
        item_key = generate_item_key(image, query)

        # 如果该项已经处理过，跳过
        if item_key in processed_items:
            print(f"跳过已处理的项：{item_key}")
            continue

        print(f"当前item的query和image是{query}, {image}")
        try:
            task, class_type, entity = get_match_task(image, query)
            # 在当前项中添加新的键值对
            item["task"] = task
            item["class_type"] = class_type
            item["entity"] = entity

            with open(task_file_path, "w", encoding="utf-8") as f:
                json.dump(task_file, f, indent=4, ensure_ascii=False)  # 确保中文字符不被转义

            print(f"更新后的内容已成功写回到 {task_file_path} \n \n")
            # 记录已处理项
            processed_items.add(item_key)
            # 完成处理后，保存已处理项
            save_processed_items(processed_items_file, processed_items)

        except Exception as e:
            print(f"模型处理过程中发生错误！错误是{e} \n 错误项是{item}")
            item["task"] = None
            item["class_type"] = None
            item["entity"] = None
            with open(task_file_path, "w", encoding="utf-8") as f:
                json.dump(task_file, f, indent=4, ensure_ascii=False)  # 确保中文字符不被转义

            print(f"写回 None 到 {task_file_path} \n \n")
            continue

        time.sleep(3)  # 每个项目暂停3s，避免封号





