import sys

# 添加目录到 sys.path
sys.path.append('/mnt/home/LLaVA_main')
sys.path.append('/mnt/home/llava-v1.6-vicuna-7b')

import argparse
import json

import torch

from llava.constants import (
    IMAGE_TOKEN_INDEX,
    DEFAULT_IMAGE_TOKEN,
    DEFAULT_IM_START_TOKEN,
    DEFAULT_IM_END_TOKEN,
    IMAGE_PLACEHOLDER,
)
from llava.conversation import conv_templates, SeparatorStyle
from llava.model.builder import load_pretrained_model
from llava.utils import disable_torch_init
from llava.mm_utils import (
    process_images,
    tokenizer_image_token,
    get_model_name_from_path,
)

from PIL import Image

import requests
from PIL import Image
from io import BytesIO
import re


def image_parser(args):
    out = args.image_file.split(args.sep)
    return out


def load_image(image_file):
    if image_file.startswith("http") or image_file.startswith("https"):
        response = requests.get(image_file)
        image = Image.open(BytesIO(response.content)).convert("RGB")
    else:
        image = Image.open(image_file).convert("RGB")
    return image


def load_images(image_files):
    out = []
    for image_file in image_files:
        image = load_image(image_file)
        out.append(image)
    return out


def prepare_query(qs, model):
    """根据模型配置调整查询语句"""
    image_token_se = DEFAULT_IM_START_TOKEN + DEFAULT_IMAGE_TOKEN + DEFAULT_IM_END_TOKEN
    if IMAGE_PLACEHOLDER in qs:
        if model.config.mm_use_im_start_end:
            qs = re.sub(IMAGE_PLACEHOLDER, image_token_se, qs)
        else:
            qs = re.sub(IMAGE_PLACEHOLDER, DEFAULT_IMAGE_TOKEN, qs)
    else:
        if model.config.mm_use_im_start_end:
            qs = image_token_se + "\n" + qs
        else:
            qs = DEFAULT_IMAGE_TOKEN + "\n" + qs
    return qs


class ModelEvaluator:
    def __init__(self, args):
        """初始化并加载模型"""
        disable_torch_init()
        self.model_name = get_model_name_from_path(args.model_path)
        self.tokenizer, self.model, self.image_processor, self.context_len = load_pretrained_model(
            args.model_path, args.model_base, self.model_name
        )

        # 确定对话模式
        if "llama-2" in self.model_name.lower():
            self.conv_mode = "llava_llama_2"
        elif "mistral" in self.model_name.lower():
            self.conv_mode = "mistral_instruct"
        elif "v1.6-34b" in self.model_name.lower():
            self.conv_mode = "chatml_direct"
        elif "v1" in self.model_name.lower():
            self.conv_mode = "llava_v1"
        elif "mpt" in self.model_name.lower():
            self.conv_mode = "mpt"
        else:
            self.conv_mode = "llava_v0"

    def generate_output(self, prompt, images_tensor, image_sizes, args):
        """使用模型生成输出"""
        input_ids = tokenizer_image_token(prompt, self.tokenizer, IMAGE_TOKEN_INDEX, return_tensors="pt").unsqueeze(
            0).cuda()

        with torch.inference_mode():
            output_ids = self.model.generate(
                input_ids,
                images=images_tensor,
                image_sizes=image_sizes,
                do_sample=True if args.temperature > 0 else False,
                temperature=args.temperature,
                top_p=args.top_p,
                num_beams=args.num_beams,
                max_new_tokens=args.max_new_tokens,
                use_cache=True,
            )

        outputs = self.tokenizer.batch_decode(output_ids, skip_special_tokens=True)[0].strip()

        return outputs

    def eval_model(self, queries, image_files, args):
        """处理多个查询和图片，返回生成的输出列表"""

        outputs_list = []

        for qs, image_file in zip(queries, image_files):
            # 加载并处理当前图片
            image = load_image(image_file)
            image_tensor = process_images([image], self.image_processor, self.model.config).to(
                self.model.device, dtype=torch.float16
            )
            image_size = [image.size]

            # 准备查询语句
            qs_prepared = prepare_query(qs, self.model)

            # 确保对话模式一致
            conv_mode = self.conv_mode
            if args.conv_mode is not None and conv_mode != args.conv_mode:
                print(
                    f"[WARNING] the auto inferred conversation mode is {conv_mode}, while `--conv-mode` is {args.conv_mode}, using {args.conv_mode}"
                )
                conv_mode = args.conv_mode

            # 准备对话模板
            conv = conv_templates[conv_mode].copy()
            conv.append_message(conv.roles[0], qs_prepared)
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt()

            # 生成输出
            output = self.generate_output(prompt, image_tensor, image_size, args)
            print(f"prompt:{qs}\n")
            print(f"image:{image_file}\n")
            print(f"output:{output}\n")
            outputs_list.append(output)

        return outputs_list


def process_json_and_run_model(args):
    """读取JSON，处理每个条目，并保存输出"""
    # 读取JSON文件
    input_json_path = args.data_path
    output_json_path = args.output_path
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # 提取所有人类的查询和图片文件
    queries = []
    image_files = []
    for item in data:
        # 提取人类的查询
        human_query = next((conv["value"] for conv in item["conversations"] if conv["from"] == "human"), None)
        if human_query:
            human_query = human_query.replace("<image>\n", "").strip()
            queries.append(human_query)
        else:
            queries.append("Hello!")  # 或者其他默认值

        # 提取图片文件路径
        image_files.append(item["image"])

    # 初始化模型评估器
    evaluator = ModelEvaluator(args)

    # 生成所有输出
    outputs = evaluator.eval_model(queries, image_files, args)

    # 将输出添加回JSON数据
    for i, item in enumerate(data):
        # 找到 "from" 为 "gpt" 的对话，并更新 "value"
        for conv in item["conversations"]:
            if conv["from"] == "gpt":
                conv["value"] = outputs[i]
                break  # 更新后即可跳出内层循环，避免不必要的遍历
    # 保存新的JSON文件
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print(f"Output saved to {output_json_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", type=str, default="/mnt/home/llava-v1.6-vicuna-7b")
    parser.add_argument("--model-base", type=str, default=None)
    parser.add_argument("--image-file", type=str, default="/mnt/home/LLaVA_main/MLLMbenchmarks/downloaded_images"
                                                          "/Animals/Dog/image_20241017_101424_1.jpg")
    parser.add_argument("--query", type=str, default="Hello!")
    parser.add_argument("--conv-mode", type=str, default=None)
    parser.add_argument("--sep", type=str, default=",")
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--top_p", type=float, default=None)
    parser.add_argument("--num_beams", type=int, default=1)
    parser.add_argument("--max_new_tokens", type=int, default=250)
    parser.add_argument("--data_path", type=str, required=True)  # 此参数是待测试数据集的路径
    parser.add_argument("--output_path", type=str, required=True)  # 其参数是输出结果的路径
    args = parser.parse_args()

    process_json_and_run_model(args)
